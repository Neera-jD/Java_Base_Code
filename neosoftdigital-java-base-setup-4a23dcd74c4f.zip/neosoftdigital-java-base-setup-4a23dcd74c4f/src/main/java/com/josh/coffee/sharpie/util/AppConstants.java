package com.josh.coffee.sharpie.util;


public final class AppConstants {

}
