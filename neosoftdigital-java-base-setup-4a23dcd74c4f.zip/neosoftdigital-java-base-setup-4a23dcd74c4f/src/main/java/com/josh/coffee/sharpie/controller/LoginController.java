package com.josh.coffee.sharpie.controller;

import com.josh.coffee.sharpie.model.request.LoginRequest;
import com.josh.coffee.sharpie.model.response.LoginResponse;
import com.josh.coffee.sharpie.model.response.ResponseDto;
import com.josh.coffee.sharpie.service.LoginService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;


@RestController
@Slf4j
@RequiredArgsConstructor
public class LoginController {

    private final LoginService loginService;

    @PostMapping("/login")
    @Operation(summary = "Login API")
    public ResponseDto<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        log.info("Received request for login {}", loginRequest);
        return loginService.login(loginRequest);
    }

}
