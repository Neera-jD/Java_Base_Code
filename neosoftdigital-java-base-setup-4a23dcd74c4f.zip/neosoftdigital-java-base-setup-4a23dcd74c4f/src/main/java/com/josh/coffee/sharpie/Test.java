package com.josh.coffee.sharpie;

import com.josh.coffee.sharpie.model.request.LoginRequest;

public class Test {
    public static void main(String[] args) throws Exception {
        LoginRequest loginRequest = LoginRequest.builder()
                .userName("ADMIN")
                .password("ADMIN")
                .build();

    }
}

