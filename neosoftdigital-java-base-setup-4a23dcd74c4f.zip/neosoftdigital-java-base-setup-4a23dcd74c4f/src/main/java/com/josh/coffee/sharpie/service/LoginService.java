package com.josh.coffee.sharpie.service;

import com.josh.coffee.sharpie.model.request.LoginRequest;
import com.josh.coffee.sharpie.model.response.LoginResponse;
import com.josh.coffee.sharpie.model.response.ResponseDto;
import com.josh.coffee.sharpie.security.AuthenticationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class LoginService {

    private final AuthenticationService authenticationService;

    public ResponseDto<LoginResponse> login(LoginRequest requestBody) {
        LoginResponse loginResponse = new LoginResponse(authenticationService.signIn(requestBody));
        return ResponseDto.<LoginResponse>builder().status(0).data(List.of(loginResponse)).build();
    }
}


