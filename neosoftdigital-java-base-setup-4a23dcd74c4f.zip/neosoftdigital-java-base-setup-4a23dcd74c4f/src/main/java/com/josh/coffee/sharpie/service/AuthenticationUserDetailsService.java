package com.josh.coffee.sharpie.service;

import com.josh.coffee.sharpie.config.SharpieServiceConfig;
import com.josh.coffee.sharpie.exceptions.CoffeeException;
import com.josh.coffee.sharpie.model.User;
import com.josh.coffee.sharpie.util.ErrorConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor

public class AuthenticationUserDetailsService {
    private final SharpieServiceConfig sharpieServiceConfig;

    public UserDetailsService userDetailsService() {
        return username -> getUser().orElseThrow
                (() -> new CoffeeException(ErrorConstants.LOGIN_USER_NOT_FOUND_ERROR_CODE, ErrorConstants.LOGIN_USER_NOT_FOUND_ERROR_MESSAGE));

    }

    public Optional<User> getUser() {
        User user = new User();
        user.setUserName(sharpieServiceConfig.getUserName());
        user.setPassword(sharpieServiceConfig.getPassword());
        user.setUserRole(List.of(sharpieServiceConfig.getUserRole()));
        return Optional.of(user);
    }
}
