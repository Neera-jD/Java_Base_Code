package com.josh.coffee.sharpie.validator;

import com.josh.coffee.sharpie.exceptions.ValidationException;
import com.josh.coffee.sharpie.model.request.LoginRequest;
import com.josh.coffee.sharpie.model.response.ErrorDto;
import com.josh.coffee.sharpie.util.ErrorConstants;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

public final class LoginValidator {

    public static void requestValidation(LoginRequest request, String appType) {
        List<ErrorDto> errorMessages = new ArrayList<>();
        if (StringUtils.isEmpty(request.getUserName())) {
            errorMessages.add(new ErrorDto(ErrorConstants.MANDATORY_ERROR_CODE, MessageFormat.format(ErrorConstants.MANDATORY_ERROR_MESSAGE, "userName")));
        }
        if (StringUtils.isEmpty(request.getPassword())) {
            errorMessages.add(new ErrorDto(ErrorConstants.MANDATORY_ERROR_CODE, MessageFormat.format(ErrorConstants.MANDATORY_ERROR_MESSAGE, "password")));
        }

        if (CollectionUtils.isNotEmpty(errorMessages)) {
            throw new ValidationException(errorMessages);
        }
    }
}
